import Calculator from '../Calculator';

export default function CalculatorExample() {
  return <Calculator />;
}