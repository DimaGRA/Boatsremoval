import ServiceSelector from '../ServiceSelector';

export default function ServiceSelectorExample() {
  return <ServiceSelector />;
}